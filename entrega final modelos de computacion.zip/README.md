# practica_ModelosDeComputacion
Repositorio de la practica de modelos de computacion

Desarollador: Juan Federico Garcia Alonso-Buron 

Grado: Ingenieria en sistemas de informacio

Desarollador: Juan Federico Garcia Alonso-Buron 

Grado: Ingenieria en sistemas de informacion
